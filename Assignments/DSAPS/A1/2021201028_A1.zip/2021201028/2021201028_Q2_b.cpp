
// Author  :-> Aman Izardar
// Email   :-> aman.izardar@students.iiit.ac.in
// Roll NO :-> 2021201028

// This is the submission for the Q2 part b) of the assignment i.e. (LFU cache)

#include <iostream>
#include <unordered_map>
#include<set>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :


class LFU
{
	unordered_map<int,pair<pair<int,int>,int>>m;  //key,val,time,freq
	int size;
	int time;
	int count;
	int a[101010][3]={0};
	set<pair<pair<int,int>,int>>s;              // freq,time,key

public:
	LFU(){}
	LFU(int capacity)
	{
		size=capacity;
		count=0;time=0;


	}


	int get(int key)
	{
		if(m.find(key)==m.end())
			return -1;

		s.erase({{m[key].second,m[key].first.second},key});   // freq,time,key
		m[key].second++;					//increasing freq
		m[key].first.second=++time;				//updating time and storing it in current key.
		s.insert({{m[key].second,m[key].first.second},key});	//storing updated freq,time with key to set
		return m[key].first.first;				//returning key


		
	}

	void Set(int key,int value)
	{

		if(size==0)
			return;


		if(m.find(key)!=m.end())
		{
			s.erase({{m[key].second,m[key].first.second},key});  // freq,time,key
			m[key].first.first=value;				//updating value
			m[key].second++;					//increasing freq
			m[key].first.second=++time;				//updating time and storing it in current key.
			s.insert({{m[key].second,m[key].first.second},key});	//storing updated freq,time with key to set
			return;
		}

		if(count<size)
			count++;
		else
		{
			auto it =*s.begin();			//LFU will be the staring one. 
			int key=it.second;			//

			m.erase(key);				//deleting LFU key from the cache
			s.erase(it);				//from the set also.
		}

		m[key]={{value,++time},1};			//inseting new key with value,updated time and freq
		s.insert({{1,time},key});			//In the set also





		
	}
};




void solve()
{


int size;
cin>>size;
LFU cache(size);



while(1){
	
int in;
cin>>in;
switch(in)
{
	case 1:
	{
		int a,b;
		cin>>a>>b;
		cache.Set(a,b);
		break;
	}
	case 2:
	{
		int a;
		cin>>a;
		cout<<cache.get(a)<<endl;
		break;
	}
	default:
	{
		exit(0);
	}
}
}


// cache.Set(1,2);
// cache.Set(2,3);
// cache.Set(3,2);
// cache.Set(4,9);
// cout<<cache.get(4);




}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
