

// Author  :-> Aman Izardar
// Email   :-> aman.izardar@students.iiit.ac.in
// Roll NO :-> 2021201028

// This is the submission for the Q2 part a) of the assignment i.e. (LRU cache)

#include<iostream>
#include<unordered_map>

#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

class Node
{
public:
	int key,value;
	Node * prev,*next;
	Node(int key1,int value1){
	key=key1;
	value=value1;}
	
};


class LRU
{
	public:
	unordered_map<int,Node*>m;
	int capacity;
	Node* head,*tail;

	LRU(int size)
	{
		capacity=size;
		head=NULL;
		tail=NULL;
	}


	void insert(Node *newnode)
	{
		if(head==NULL)
		{
			head=newnode;
			tail=newnode;
			return;
		}

		newnode->next=head;
		head->prev=newnode;
		head=head->prev;
	}

	void deletenode(Node *oldnode)
	{
		if(head==oldnode and tail==oldnode)
		{
			oldnode->next=NULL;
			oldnode->prev=NULL;
			// free(oldnode);
		}

		if(oldnode==head)
		{
			head=head->next;
			head->prev=NULL;
			oldnode->next=NULL;
			// free(oldnode);
		}
		else if(oldnode==tail)
		{
			tail=tail->prev;
			tail->next=NULL;
			oldnode->prev=NULL;
			// free(oldnode);
		}
		else
		{
			oldnode->prev->next=oldnode->next;
			oldnode->next->prev=oldnode->prev;
			oldnode->prev=NULL;
			oldnode->next=NULL;
			// free(oldnode);
		}
	}

	int get(int key)
	{
		if(m.count(key))
		{
			Node* temp=m[key];
			int val = temp->value;
			deletenode(temp);
			insert(temp); //front
			return val;
		}
		return -1;
	}

	void set(int key,int value)
	{
		Node* temp=new Node(key,value);

		if(m.count(key))
		{
			Node *oldnode=m[key];
			deletenode(oldnode);
			insert(temp);
			m[key]=temp;
		}

		else
		{
			if(m.size()==capacity)
			{
				Node *lru=tail;
				m.erase(lru->key);
				deletenode(lru);
				insert(temp);
				m[key]=temp;
			}
			else
			{
				capacity++;
				insert(temp);
				m[key]=temp;
			}
		}
	}

};


void solve()
{

int size;
cin>>size;
LRU cache(size);

while(1){
	
int in;
cin>>in;
switch(in)
{
	case 1:
	{
		int a,b;
		cin>>a>>b;
		cache.set(a,b);
		break;
	}
	case 2:
	{
		int a;
		cin>>a;
		cout<<cache.get(a)<<endl;
		break;
	}
	default:
	{
		exit(0);
	}
}
}
// cache.set(1,2);
// cache.set(2,3);
// cache.set(3,1);
// cache.set(4,5);
// cout<<cache.get(4);








}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
