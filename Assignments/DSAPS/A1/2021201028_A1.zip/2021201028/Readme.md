///////////////////////////////////////This is a readme file///////////////////////////////////////
Author :-> Aman Izardar
Email :-> aman.izardar@students.iiit.ac.in
Roll no :-> 2021201028


                                    FOR Q1:->
- Bigint Library in c++.
- Implemented using class.
- Supports Exponentiation, Factorial, GCD ,and Expession Evaluation of Large Numbers.
# Input Format :
- First line contains a number between 1 to 4
    - 1 : For Exponentiation
    - 2 : For GCD
    - 3 : For Factorial 
    - 4 : For Expression Evaluation (Calculator)
- Second line Contains 2 Space seprated Numbers in case of Exponentiation(Base followed by Exponent) or 
- 2 space seprated numbers in case of GCD or 
- 1 number in case of Factorial or 
- A string containing numbers with operators in case of Expression Evaluation (Calculator).


------Example Test Case 1:
   1
   2 34

------Example Test Case 2:
2
65 75

------Example Test Case 3:
3
1000

------Example Test Case 4:
4
10-2x3

  
***
---
----

                                    For Q2:->
@ LRU Cache and @ LFU cache
# Input Format :
-  first line contains one integar size of the cache.
-  followed by some lines of set and get operations.
-  1 for the set operation and 2 for get operation on the cache.
-  For the set operation, the next line contains two integars (Key and Value).
-  For the get operation,the next line contains only one integar (Key).
-  Next Line contains any number other than 1 and 2 to exit from the program.


------Sample Test Case 1:
3
1 2 5
2 1
3


------Sample Test Case 2:
5
1 2 5
2 1
1 6 2
1 3 5
2 4 
2 3
3


***
***
***

                                    For Q3:->
@ Sparse Matrix Operations
@ Using array and LL
# input format:
  @ First line contains an int between 1-3
       1 : for addition 
       2 : for multiplication
       3 : for transpose
       
  @ Next line will contain the size of two matrix in case of addition and multiplicaton
  or size of one matrix in case of transpose
  
  @ next line contain array elements
  @ two matrix in case of addition and multiplication
  @ one matrix in case of transpose
  
------Sample Test Case 1:
  
  1
  3 3 3 3
  1 0 1
  0 0 5
  0 4 0
  5 0 0
  2 0 1
  0 3 0
  
------Sample Test Case 2:  
  3
  3 3
  1 0 5
  9 5 0
  0 0 6
  




