
// Author  :-> Aman Izardar
// Email   :-> aman.izardar@students.iiit.ac.in
// Roll NO :-> 2021201028

// This is the submission for the Q3 a) of the assignment 

#include <iostream>
#include <iomanip>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

#define MAX 5000

template<class T>
class matrix
{
	int row,col;
	int size;
	


public:
	T **comp;
	int len;
		
	matrix(int r,int c)
	{
		row=r;
		col=c;
		size=0;
		len=0;
		comp = new T *[MAX];
		for (int i = 0; i < MAX; i++)
            comp[i] = new T[3];
	}


	void put(int r, int c, int val)
    {
  
        if (r > row || c > col)
  
            cout << "Error";
   
        else
        {
            comp[len][0] = r;
            comp[len][1] = c;
            comp[len][2] = val;
            len++;
        }
    }

	void input()
	{
		
		int k=0;
		T a;
		for(int i=0;i<row;i++)
		{
			for (int j=0;j<col;j++)
			{
				cin>>a;
				if(a!=0)
				{
					comp[k][0]=i;
					comp[k][1]=j;
					comp[k][2]=a;
					k++;
					len++;
					size++;

				}
			}
		}
		
	}

	void output()
	{
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<len;j++)
			{
				cout<<setw(2)<<comp[j][i]<<" ";
			}
			cout<<endl;
		}
	}

	matrix add(matrix b)
	{
		matrix ans(row,col);
		if(row!=b.row or col!=b.col){
			cout<<"Error, Can not add these matrices";
			return ans;
		}


		else
		{
			int i=0,j=0;
			
			while(i<len and j<b.len)
			{
				if(comp[i][0]<b.comp[j][0] or (comp[i][0]==b.comp[j][0] and comp[i][1]<b.comp[j][1]))
				{
					ans.put(comp[i][0],comp[i][1],comp[i][2]);
					i++;
				}
				else if(comp[i][0]>b.comp[j][0] or (comp[i][0]==b.comp[j][0] and comp[i][1]>b.comp[j][1]))
				{
					ans.put(b.comp[j][0],b.comp[j][1],b.comp[j][2]);
					j++;
				}
				else
				{
					T sum=comp[i][2]+b.comp[j][2];
					if(sum!=0)
					ans.put(comp[i][0],comp[i][1],sum);
					i++;
					j++;
				}
			}
			while(i<len)
			{
				ans.put(comp[i][0],comp[i][1],comp[i][2]);
				i++;

			}
			while(j<len)
			{
				ans.put(b.comp[j][0],b.comp[j][1],b.comp[j][2]);
				i++;
			}
			
		}
		return ans;
												//Aman Izardar//
	}

	matrix transpose()
	{
		matrix ans(col,row);
		
		for(int i=0;i<col;i++)   //col ranging from 0 to col
		{
			for(int j=0;j<len;j++)   // row ranging from 0 to len
			{
				if(i==comp[j][1])   //first all col val==0 then all col==1 and so on...
				{
					ans.put(i,comp[j][0],comp[j][2]);  // col,row,valuel
				}
			}
		}
		return ans;
	}

	matrix mul(matrix b)
	{
		
		matrix ans(row,b.col);
		if(col!=b.row)
		{
			cout<<"Error, Cant not mul these matrices";
			return ans;
		}

		b=b.transpose();

		int i,j;
		
		

		for(i=0;i<len;)
		{
			int r=comp[i][0];

			for(j=0;j<b.len;)
			{
				int c=b.comp[j][0];

				int ii=i,jj=j;
				int sum=0;

				while(ii<len and jj<b.len and comp[ii][0]==r and b.comp[jj][0]==c)
				{
					if(comp[ii][1]<b.comp[jj][1])
						ii++;
					else if(comp[ii][1]>b.comp[jj][1])
						jj++;
					else
					{
						sum+=((comp[ii][2])*(b.comp[jj][2]));
						ii++;
						jj++;

					}
				}

				if(sum!=0)
				{
					ans.put(r,c,sum);
				}

				while(j<b.len and b.comp[j][0]==c)
					
					j++;
				
				


			}
			while(i<len and comp[i][0]==r)
					i++;

		}
		return ans;
	}




};


void solve()
{




int in;   // 1 for additon, 2 for multiplication, 3 for transpose
cin>>in;

switch(in)
{
	case 1:   //for Addition
	{
		int r1,c1,r2,c2;
		cin>>r1>>c1>>r2>>c2;
		matrix<int>m1(r1,c1);
		m1.input();
		matrix<int>m2(r2,c2);
		m2.input();
		matrix<int>m3=m1.add(m2);
		m3.output();
		break;
	}

	case 2:   //for Multiplication
	{
		int r1,c1,r2,c2;
		cin>>r1>>c1>>r2>>c2;
		matrix<int>m1(r1,c1);
		m1.input();
		matrix<int>m2(r2,c2);
		m2.input();
		matrix<int>m3=m1.mul(m2);
		m3.output();
		break;
	}

	case 3:   // For transpose
	{
		int r1,c1;
		cin>>r1>>c1;
		matrix<int>m1(r1,c1);
		m1.input();
		matrix<int>m3=m1.transpose();
		m3.output();
		break;
	}
	
	default:
	{
		break;
	}
}

// matrix<double>m(3,3);
// m.input();
// m.output();
// cout<<endl;
// matrix<double>m2(3,3);
// m2.input();
// m2.output();
// cout<<endl;
// matrix<int>c=m.add(m2);
// c.output();
// matrix<int >m(3,3);
// m.put(1,2,5);
// m.output();
// matrix<double>d=m2.transpose();
// d.output();
// cout<<endl;

// matrix<double>e=m.mul(m2);
// e.output();
// cout<<"hi";




}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
