

// Author  :-> Aman Izardar
// Email   :-> aman.izardar@students.iiit.ac.in
// Roll NO :-> 2021201028

// This is the submission for the Q3 b) of the assignment  

#include<iostream>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :




template<class T>
class matrix
{
	int rowc,colc;

	class Node
	{
	public:
	int row;
	int col;
	T value;
	Node *next;

	Node(int row1,int col1,T value1)
	{
		row=row1;
		col=col1;
		value=value1;
		next=NULL;
	}
	};
	


public:
	Node* head,*tail;
	matrix()
	{
		head=NULL;
		tail=NULL;
	}
		
	matrix(int r,int c)
	{
		rowc=r;
		colc=c;
		head=NULL;
		tail=NULL;
	}

	void input()
	{
		T a;
		for(int i=0;i<rowc;i++)
		{
			for(int j=0;j<colc;j++)
			{
				cin>>a;
				if(a!=0)
				{
					insert(i,j,a);
				}
			}
		}
	}

	void insert(int row,int col,T value)
	{
		Node *newnode = new Node(row,col,value);

		if(head==NULL)
		{
			head=newnode;
			tail=newnode;
		}
		else
		{
			tail->next=newnode;
			tail=tail->next;
		}
	}

	void print()
	{
		Node *temp=head;
		while(temp)
		{
			cout<<temp->row<<" ";
			temp=temp->next;
		}
		cout<<"\n";
		temp=head;
		while(temp)
		{
			cout<<temp->col<<" ";
			temp=temp->next;
		}
		cout<<"\n";
		temp=head;
		while(temp)
		{
			cout<<temp->value<<" ";
			temp=temp->next;
		}
		cout<<"\n";


	}

	matrix add(matrix b)
	{
		matrix ans;

		Node *temp1=head;
		Node *temp2=b.head;

		while(temp1 and temp2)
		{
			if(temp1->row < temp2->row or ((temp1->row == temp2->row) and (temp1->col < temp2->col)))
			{
				ans.insert(temp1->row,temp1->col,temp1->value);
				temp1=temp1->next;
			}
			else if(temp1->row > temp2->row or ((temp1->row == temp2->row) and (temp1->col > temp2->col)))
			{
				ans.insert(temp2->row,temp2->col,temp2->value);
				temp2=temp2->next;
			}
			else
			{
				int sum=temp1->value + temp2->value;
				if(sum!=0)
					ans.insert(temp1->row,temp1->col,sum);
				temp1=temp1->next;
				temp2=temp2->next;
			}
		
		}
		while(temp1)
		{
			ans.insert(temp1->row,temp1->col,temp1->value);
			temp1=temp1->next;
		}
		while(temp2)
		{
			ans.insert(temp2->row,temp2->col,temp2->value);
			temp2=temp2->next;
		}

		 return ans;

	}

	matrix transpose()
	{
		Node *temp=head;
		matrix ans;

		while(temp)
		{
			ans.insert_sorted(temp->col,temp->row,temp->value);
			temp=temp->next;
		}
		return ans;

	}
	void insert_sorted(int row,int col,int value)
	{
		Node *newnode = new Node(row,col,value);

		if(head==NULL)
		{
			head=newnode;
			tail=newnode;
		}
		else
		{
			Node *temp = head;
			if(newnode->row<temp->row or (newnode->row==temp->row and (newnode->col<temp->col)))
			{
				newnode->next=temp;
				head=newnode;
				return;
			}
			if((newnode->row>temp->row) or (newnode->row==temp->row and (newnode->col>temp->col)))
			{
				newnode->next=temp->next;
				temp->next=newnode;
				return;
			}

			while(temp->next and newnode->row>temp->next->row)
			{
				temp=temp->next;
			}
			if(!temp->next)
			{
				temp->next=newnode;
				tail=newnode;
				return;
			}

			if(newnode->row<temp->next->row or (newnode->row==temp->next->row and (newnode->col<temp->next->col)))
			{
				newnode->next=temp->next;
				temp->next=newnode;
				return;
			}
			if((newnode->row>temp->next->row) or((newnode->row==temp->next->row) and (newnode->col>temp->next->col)))
			{
				temp->next->next=newnode;
				return;
			}
			
		}
	}



	matrix mul(matrix b)
	{
		matrix res;
		Node *t1,*t2,*temp;
		t1=head;
		t2=b.head->next;
		while(t1)
		{
			t2=b.head;
			while(t2)
			{
				if(t1->col == t2->row)
				{
					res.insert(t1->row,t2->col,((t1->value)*(t2->value)));
				}
				t2=t2->next;
			}
			t1=t1->next;
		}
		return res;
	}

};



void solve()
{




int in;   // 1 for additon, 2 for multiplication, 3 for transpose
cin>>in;

switch(in)
{
	case 1:   //for Addition
	{
		int r1,c1,r2,c2;
		cin>>r1>>c1>>r2>>c2;
		matrix<int>m1(r1,c1);
		m1.input();
		matrix<int>m2(r2,c2);
		m2.input();
		matrix<int>m3=m1.add(m2);
		m3.output();
		break;
	}

	case 2:   //for Multiplication
	{
		int r1,c1,r2,c2;
		cin>>r1>>c1>>r2>>c2;
		matrix<int>m1(r1,c1);
		m1.input();
		matrix<int>m2(r2,c2);
		m2.input();
		matrix<int>m3=m1.mul(m2);
		m3.output();
		break;
	}

	case 3:   // For transpose
	{
		int r1,c1;
		cin>>r1>>c1;
		matrix<int>m1(r1,c1);
		m1.input();
		matrix<int>m3=m1.transpose();
		m3.output();
		break;
	}
	
	default:
	{
		break;
	}
}





//matrix<float>m(3,3);

//m.input();
//m.print();
//cout<<"\n";

// matrix<float>m2(3,3);
// m2.input();
// m2.print();
// cout<<"\n";

// matrix<float>m3=m.add(m2);
// m3.print();
// cout<<"\n";

// matrix<float>m4=m2.transpose();
// m4.print();
// cout<<"\n";

// matrix<float>m5=m.mul(m2);
// m5.print();
}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
