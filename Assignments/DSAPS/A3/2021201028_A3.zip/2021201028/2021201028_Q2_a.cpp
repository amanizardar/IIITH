//Author :-> Aman Izardar
// Enroll no : 2021201028
// Email : aman.izardar@students.iiit.ac.in
// Submission for The Assignment 3 of DSA 
// Question 2 part a

#include<iostream>
#include<vector>
#include<algorithm>
#include<limits.h>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :


struct PriorityQueue
{
private:
   
    vector<pair<int,int>> A;
 

    int PARENT(int i) {
        return (i - 1) / 2;
    }
 
    int LEFT(int i) {
        return (2*i + 1);
    }

    int RIGHT(int i) {
        return (2*i + 2);
    }
 

    void heapify_down(int i)
    {

        int left = LEFT(i);
        int right = RIGHT(i);
 
        int smallest = i;

        if (left < size() && A[left].first < A[i].first) {
            smallest = left;
        }
 
        if (right < size() && A[right].first < A[smallest].first) {
            smallest = right;
        }

        if (smallest != i)
        {
            swap(A[i], A[smallest]);
            heapify_down(smallest);
        }
    }
 
    void heapify_up(int i)
    {
    
        if (i && A[PARENT(i)].first > A[i].first)
        {
           
            swap(A[i], A[PARENT(i)]);
            heapify_up(PARENT(i));
        }
    }
 
public:

    unsigned int size() {
        return A.size();
    }

    bool empty() {
        return size() == 0;
    }
 
    void push(int key,int value)
    {
   
        A.push_back({key,value});
        int index = size() - 1;
        heapify_up(index);
    }
 
    void pop()
    {
        try {

            if (size() == 0)
            {
                throw out_of_range("Vector<X>::at() : "
                        "index is out of range(Heap underflow)");
            }

            A[0] = A.back();
            A.pop_back();

            heapify_down(0);
        }
        catch (const out_of_range &oor) {
            cout << endl << oor.what();
        }
    }

    pair<int,int> top()
    {
        try {
    
            if (size() == 0)
            {
                throw out_of_range("Vector<X>::at() : "
                        "index is out of range(Heap underflow)");
            }
 
        
            return A.at(0);        
        }

        catch (const out_of_range &oor) {
            cout << endl << oor.what();
        }
        return {0,0};
    }
};

string from(int v,vector<int>&par)
{
	string path;
	while(par[v]!=-1)
	{
		path+=(v+'0');
		v=par[v];
	}
	path+=(v+'0');
	reverse(path.begin(),path.end());
	return path;
}

bool lexi(string s1,string s2)
{
	int n =min(s1.length(),s2.length());

	for(int i=0;i<n;i++)
	{
		if(s1[i]>s2[i])
			return false;
	}
	return true;
}

void addEdge(vector<pair<int,int>>adj[],int u,int v,int w)
{
    adj[u].push_back({v,w});
    adj[v].push_back({u,w});
}


void dijkstra(vector<pair<int,int>>adj[],int V,int src)
{
    vector<int>dis(V,INT_MAX);
    vector<int>par(V,-1);
    dis[src]=0;
    
    // priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>pq;
    PriorityQueue pq;
    pq.push(0,src);
    while(!pq.empty())
    {
        int u = pq.top().second;
        pq.pop();
        
        for(auto v : adj[u])
        {
            int v1 = v.first;
            int w = v.second;
            
            if(dis[v1]>dis[u]+w)
            {
                dis[v1]=dis[u]+w;
                par[v1]=u;
                pq.push(dis[v1],v1);
            }

	        else if(dis[v1]==dis[u]+w )
	            {
	            	string path1 = from(u,par)+to_string(v1);
	            	string path2 = from(v1,par);
	            	reverse(path1.begin(),path1.end());
	            	reverse(path2.begin(),path2.end());
	            	if(lexi(path1,path2))
	            	par[v1]=u;
	        	}
        }
    }





    	for(int i=0;i<V;i++)
			{
				if(i!=src)
				{
					vector<int>res;
	        		int k=i;

	        		while(par[k]!=-1)
	        		{
	        			res.push_back(k);
	        			k=par[k];
	        		}

	        		res.push_back(src);
	        		
	        		for(auto i:res)
	        		{
	        			cout<<i<<" ";
	        		}
	        		cout<<endl;
	    		}
	    	}
    
}




void solve()
{

	int n,m;
    cin>>n>>m;
    std::vector<pair<int,int>>adj[n];
    for(int i=0;i<m;i++)
    {
        int x,y,z;
        cin>>x>>y>>z;
        addEdge(adj,x,y,z);
    }

    int d;
    cin>>d;

    // for(int i=0;i<n;i++)
    // {
    	// if(i!=d)
    	dijkstra(adj,n,d);
    // }



// int V=8;
// 	std::vector<pair<int,int>>adj[V];
// 	addEdge(adj,1,2,2);
// 	addEdge(adj,1,0,1);
// 	addEdge(adj,3,0,3);
// 	addEdge(adj,3,7,5);
// 	addEdge(adj,3,4,6);
// 	addEdge(adj,4,7,2);
// 	addEdge(adj,4,6,1);
// 	addEdge(adj,4,5,9);
// 	addEdge(adj,7,6,4);
// 	addEdge(adj,5,6,3);
	
// 	int src =4,des=0;
// 	// vector<int> res = 
// 	dijkstra(adj,V,src,des);
	
	// for(int i=0;i<V;i++)
	// {
	//     cout<<res[i]<<" ";
	// }
	






}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
