
//Author :-> Aman Izardar
// Enroll no : 2021201028
// Email : aman.izardar@students.iiit.ac.in
// Submission for The Assignment 3 of DSA 
// Question 2 part b

#include<iostream>
#include<vector>
#include<algorithm>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :
vector<pair<int,string>>path;

void addEdge(vector<pair<int,int>>adj[],int u,int v,int w)
{
    adj[u].push_back({v,w});
    adj[v].push_back({u,w});
}

void dfsfun(vector<pair<int,int>>adj[],int i,string &word,vector<pair<int,string>>&path,vector<int>&visited,int currdis)
{
	if(visited[i]==1)
		return;

	visited[i]=1;

	for(auto u:adj[i])
	{
		int v = u.first;
		int w = u.second;

		if(visited[v]==0)
		{
		
		word+=to_string(v);
		if(word[0]<(v+'0')){
		path.push_back({w+currdis,word});
		}
		
		dfsfun(adj,v,word,path,visited,w+currdis);
		word.pop_back();

		visited[v]=0;
		}
	}




}



void dfs(vector<pair<int,int>>adj[],int src,int n)
{
	vector<int>visited(n,0);
	visited[src]=1;

	
	string walk=to_string(src);

	for(auto u:adj[src])
	{
		int v = u.first;
		int w = u.second;

		
		walk+=to_string(v);
		if(walk[0]<(v+'0')){
		path.push_back({w,walk});}
		dfsfun(adj,v,walk,path,visited,w);
		walk.pop_back();

		visited[v]=0;
	
	}

	
}


void solve()
{



int n,m;
    cin>>n>>m;
    std::vector<pair<int,int>>adj[n];
    for(int i=0;i<m;i++)
    {
        int x,y,z;
        cin>>x>>y>>z;
        addEdge(adj,x,y,z);
       
    }

    int k;
    cin>>k;


    // dfs(adj,0,n);
    // dfs(adj,1,n);



    for(int i=0;i<n;i++)
    dfs(adj,i,n);


// for(auto i :path)
	// {
	// 	cout<<i.second<<" "<<i.ff<<endl;
	// }

sort(path.begin(),path.end());

	

if(k>path.size())
{
	k=path.size();
}


	for(int i=0;i<k;i++)
	{
		// cout<<path[i].ss<<endl;
		for(int j=0;j<path[i].ss.length();j++)
		{
			cout<<path[i].ss[j]<<" ";
		}
		cout<<endl;
	}

}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
