
//Author :-> Aman Izardar
// Enroll no : 2021201028
// Email : aman.izardar@students.iiit.ac.in
// Submission for The Assignment 3 of DSA 
// Question 2 part c

#include<iostream>
#include<vector>
#include<queue>
#include<limits.h>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;






//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :


bool isvalid(int x,int y,vector<vector<char>>&a,vector<vector<int>>&visited,int n,int m)
{
	if((x>=0) and (x<n) and (y>=0) and (y<m) and (a[x][y]!='#')  and (visited[x][y]==0))
		return true;
	return false;
}

void bfs(int i,int j,vector<vector<char>>&a,int n,int m,vector<int>&time,int &mytime)
{

	vector<vector<int>>visited(n,vector<int>(m,0));

	visited[i][j]=1;

	int dx[4]={1,-1,0,0};
	int dy[4]={0,0,1,-1};


	queue<pair<int ,pair<int,int>>>q;
	q.push({0,{i,j}});

	while(!q.empty())
	{
		auto x =q.front();
		q.pop();
		int dis=x.ff;
		int ii=x.ss.ff;
		int jj=x.ss.ss;

		if(a[ii][jj]=='R')
			time.push_back(dis);
		else if(a[ii][jj]=='A')
			mytime=dis;

		for(int i=0;i<4;i++)
		{
			int x1=ii+dx[i];
			int y1=jj+dy[i];

			if(isvalid(x1,y1,a,visited,n,m))
			{

				q.push({dis+1,{x1,y1}});
				visited[x1][y1]=1;
			}
		} 
	}

}



void solve()
{


int n,m;
cin>>n>>m;

vector<vector<char>>a(n,vector<char>(m));
for (int i = 0; i < n; ++i)
{
	for(int j=0;j<m;j++)
	{
		cin>>a[i][j];
	}
		
}


vector<int>time;
int mytime=INT_MAX;



bfs(1,0,a,n,m,time,mytime);

if(time.size()==0 and mytime==INT_MAX)
{
	cout<<"NO"<<endl;
	return;
}

for(int i=0;i<time.size();i++)
{
	if(time[i]<mytime)
	{
		cout<<"NO"<<endl;
		return;
	}
}

cout<<"YES"<<endl;
cout<<mytime<<endl;


}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}

