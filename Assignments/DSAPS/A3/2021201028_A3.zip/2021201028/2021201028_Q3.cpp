
//Author :-> Aman Izardar
// Enroll no : 2021201028
// Email : aman.izardar@students.iiit.ac.in
// Submission for The Assignment 3 of DSA 
// Question 3

#include<iostream>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

#define alpsize 26

class Trie
{

public:
	Trie *child[alpsize];
	int last;

int r,c;
char **matrix;
	
int dx[4]={0,1,-1,0};
int dy[4]={1,0,0,-1};




	Trie()
	{

		last=0;
		for (int i = 0; i < alpsize; ++i)
		{
			child[i]=NULL;
		}
	}

	void insert(Trie *root,string s)
	{
		Trie *temp=root;

		int n=s.length();
		for(int i=0;i<s.length();i++)
		{
			int index=s[i]-'a';
			if(temp->child[index]==NULL)
				temp->child[index]=new Trie();
			temp=temp->child[index];
		}
		temp->last=1;
	}

	void spellcheck(Trie *root,string s)
	{
		Trie *temp=root;

		int n=s.length();
		for(int i=0;i<n;i++)
		{
			int index=s[i]-'a';
			if(!temp->child[index]){
				cout<<0<<endl;
				return;
			}
			temp=temp->child[index];
		}
		if(temp->last)
		cout<<1<<endl;
		else
		cout<<0<<endl;
	}

	bool isend(Trie *temp)
	{
		for(int i=0;i<alpsize;i++)
		{
			if(temp->child[i])
				return false;

		}
		return true;
	}



	void print(Trie *root)
	{
		for(int i=0;i<alpsize;i++)
		{
			if(root->child[i])
			{
				char ch =  i+'a';
				cout<<ch<<" ";
				print(root->child[i]);
			}

		}
	}

	void printmatrix()
	{
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				cout<<matrix[i][j]<<" ";
			}
			cout<<endl;
		}
	}

	void input()
	{
		
		cin>>r>>c;

		matrix = new char*[r];

		for (int i = 0; i < r; i++)
		{
        	matrix[i] = new char[c];
    	}

		for (int i = 0;i<r;++i)
		{
			for(int j=0;j<c;j++)
			{
				cin>>matrix[i][j];
			}
		}

		

	}

	void findword(Trie *root)
	{
		for(int k=0;k<alpsize;k++)
		{
			for(int i=0;i<r;i++)
			{
				for(int j=0;j<c;j++)
				{
					if(matrix[i][j]==k+'a')
					{
						int index=matrix[i][j]-'a';
						if(root->child[index])
						{
							// cout<<root->child[index]<<endl;
							check(root->child[index], i,j,"");
						}
					}
				}
			}
		}
	}

	bool notvalid(int x,int y,Trie *root)
	{
		if(x<0 or x>=r or y<0 or y>=c or matrix[x][y]=='$' or root->child[matrix[x][y]-'a']==NULL )
			return true;
		return false;
	}

	void check(Trie *root ,int i ,int j,string currstring)
	{
		// if(!root)
		// {
		// 	return;
		// }

		currstring.push_back(matrix[i][j]);
		if(root->last>0)
		{
			cout<<currstring<<" ";
			root->last--;


		}
		
		char prev=matrix[i][j];
		matrix[i][j]='$';

		for(int k=0;k<4;k++)
		{
			int x=i+dx[k];
			int y=j+dy[k];

			if(notvalid(x,y,root))
				continue;
			int index=matrix[x][y]-'a';
			check(root->child[index],x,y,currstring);
		}
		matrix[i][j]=prev;

	}


};








void solve()
{

Trie T;
Trie *root = &T;
T.input();
int x;
cin>>x;
string s;
for(int i=0;i<x;i++)
{
	cin>>s;
	T.insert(root,s);
	
}

// T.printmatrix();
T.findword(root);



}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
