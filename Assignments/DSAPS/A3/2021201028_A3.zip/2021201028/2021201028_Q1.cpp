
//Author :-> Aman Izardar
// Enroll no : 2021201028
// Email : aman.izardar@students.iiit.ac.in
// Submission for The Assignment 3 of DSA 
// Question 1



#include<iostream>
#include<vector>
#include<unordered_map>
#include<map>
#include<algorithm>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :


#define alpsize 26
vector<string>ans;

struct trie
{
    typedef unordered_map<char, trie*> next_t;
 	bool last;
    next_t next;
    string word;
    trie() : next(unordered_map<char, trie*>()) {last=false;}

    void insert(string w)
    {
        w = string("$") + w;
        int size = w.size();
         
        trie* n = this;
        for (int i = 0; i < size; ++i)
        {
            if (n->next.find(w[i]) == n->next.end())
            {
                n->next[w[i]] = new trie();
            }
 
            n = n->next[w[i]];
        }
 
        n->word = w;
        last=true;
    }

    void spellcheck(string w)
	{
		
		w = string("$") + w;
		int size=w.length();
		trie* n = this;
		for (int i = 0; i < size; ++i)
		{
            if (n->next.find(w[i]) == n->next.end()) 
            {
                cout<<0<<endl;
                return;
            }
 
            n = n->next[w[i]];
        }

        if(n->word==w)
        	cout<<1<<endl;
		else
		cout<<0<<endl;
		
 
 
	}

	bool isend(trie *temp)
	{
		for(int i=0;i<alpsize;i++)
		{
			if(temp->next.find(i+'a') != temp->next.end())
				return false;
		}
		return true;
	}

	void autocomplete(string w)
	{
		int flag=0;
		trie *root=this;
		vector<string>v;
		
		w = string("$") + w;
		trie* n = this;
		int size=w.length();
		for (int i = 0; i < size; ++i) 
		{
            if (n->next.find(w[i]) == n->next.end()) 
            {
                flag=1;
				break;
            }
 
            n = n->next[w[i]];
        }

		if(flag==1)
		{
			cout<<"No string Found"<<"\n";
			return;
		}

		if(isend(n))
		{
			cout<<w<<endl;
			cout<<"hi";
			return;
		}

		else
		{
			autocompletefun(n,w,v);
		}

		cout<<v.size()<<endl;
		for(int i=0;i<v.size();i++)
		{
			cout<<v[i]<<endl;
		}
		return;





	}

	void autocompletefun(trie *temp,string currstring,vector<string>&v)
	{

		if(temp->word!="")
			v.push_back(currstring.substr(1));
		if(isend(temp))
			return;
		for(int i=0;i<alpsize;i++)
		{
			if(temp->next.find(i+'a') != temp->next.end())
			{
				currstring.push_back('a'+i);
				autocompletefun(temp->next[i+'a'],currstring,v);
				currstring.pop_back();
			}
		}
	}

	void autocorrect(string word)
	{
	ans.clear();
    word = string("$") + word;
    trie *n=this;
     
    int size = word.size();
 
    vector<int> curr(size + 1);
 
    for (int i = 0; i < size; ++i)
     curr[i] = i;

    curr[size] = size;
     
    for (int i = 0 ; i < size; ++i) 
    {
        if (n->next.find(word[i]) != n->next.end()) 
        {
            searchfun(n->next[word[i]], word[i], curr, word);
        }
    }

    cout<<ans.size()<<endl;
    for(auto i:ans)
    {
    	cout<<i<<endl;
    }
    
}


void searchfun(trie* tree, char ch, vector<int> last_row, const string& word)
{
    int size = last_row.size();
 
    vector<int> curr(size);
    curr[0] = last_row[0] + 1;
 
   
    int insdel, replace;
    for (int i = 1; i < size; ++i) {
        insdel = min(curr[i-1] + 1, last_row[i] + 1);
        replace = (word[i-1] == ch) ? last_row[i-1] : (last_row[i-1] + 1);
 
        curr[i] = min(insdel, replace);
    }
 




    if(curr[size-1]<=3 and tree->word!="")
    {
    	ans.push_back(tree->word.substr(1));
    }


    if (*min_element(curr.begin(), curr.end()) < 3) 
    {
        for (trie::next_t::iterator it = tree->next.begin(); it != tree->next.end(); ++it) 
        {
            searchfun(it->second, it->first, curr, word);
        }
    }
}
 




};
 


 



void solve()
{

// trie tree;




// tree.insert("aman");
// tree.insert("amanji");

// tree.autocomplete("ama");

// tree.spellcheck("aman");

// tree.spellcheck("amanji");


// tree.autocorrect("ama");
// tree.autocorrect("amanj");


trie T;
// trie *root=&T;
int n;
cin>>n;

for (int i = 0; i < n; ++i)
{
	string word;
	cin>>word;
	T.insert(word);
}

int a;
string t;

cin>>a>>t;

switch(a)
{
	case 1:
	{
		T.spellcheck(t);
		break;
	}
	case 2:
	{
		T.autocomplete(t);
		break;
	}
	case 3:
	{
		T.autocorrect(t);
		break;

	}
}


}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
