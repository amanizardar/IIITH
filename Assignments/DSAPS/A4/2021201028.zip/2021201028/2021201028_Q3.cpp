
//Author :-> Aman Izardar
// #include <bits/stdc++.h>
#include<iostream>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;

//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

class Trie
{
	Trie *child[2];
	bool isleaf;

public:
	Trie()
	{
		child[0] = NULL;
		child[1] = NULL;
		isleaf = false;
	}

	bool check(ll N, ll i)
	{
		return (bool)(N & (1 << i));
	}

	void insert(ll x)
	{
		Trie *root = this;
		Trie *temp = root;

		for (ll i = 31; i >=0; i--)
		{
			ll tt = check(x, i);
			if (!temp->child[tt])
				temp->child[tt] = new Trie();
			temp = temp->child[tt];
		}
		temp->isleaf = true;
	}

	ll Xor(ll x)
	{
		Trie *temp = this;

		ll ans = 0;
		for (ll i =31; i >= 0; i--)
		{

			ll tt = check(x, i);
			if ((temp->child[tt ^ 1]))
			{
				ans = ans + (1 << i);
				temp = temp->child[tt ^ 1];
			}

			else
				temp = temp->child[tt];
		}

		return ans;
	}
};

void solve()
{

	Trie *root = new Trie();

	ll n, q;
	cin >> n >> q;

	ll v[n];

	for (int i = 0; i < n; ++i)
	{
		cin >> v[i];
		root->insert(v[i]);
	}

	for (int i = 0; i < q; ++i)
	{
		ll a;
		cin >> a;

		cout << root->Xor(a) << endl;
	}
}

int main()
{

	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll t = 1;
	//cin>>t;
	while (t--)
	{
		solve();
	}
	return 0;
}
