
//Author :-> Aman Izardar
#include<iomanip>
#include<iostream>
#include<cstring>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

class suffix
{
    int dex_in;
    int s[2];
public:

    int sortfun(struct suffix a, struct suffix b)
    {
        int temp;
        if (a.s[0] == b.s[0])
        {
            temp = 0;
            temp = (a.s[1] < b.s[1] ? 1 : 0);
        }
        else
        {
            temp = 0;
            temp = (a.s[0] < b.s[0] ? 1 : 0);
        }
            
        return temp;
    }

    void radixSort(struct suffix suffixes[], int n, int dex_in)
    {
        int position_array[257];
        int i;
        struct suffix *temp = new struct suffix[n];
        memset(position_array, 0, sizeof(position_array));
        for (i = 0; i < n; i++)
        {
            position_array[suffixes[i].s[dex_in] + 1]++;
        }
        for (i = 1; i < 256; i++)
        {
            position_array[i] += position_array[i - 1];
        }
        for (i = n - 1; i >= 0; i--)
        {
            temp[position_array[suffixes[i].s[dex_in] + 1] - 1] = suffixes[i];
            position_array[suffixes[i].s[dex_in] + 1]--;
        }
        for (i = 0; i < n; i++)
        {
            suffixes[i] = temp[i];
        }
        free(temp);
        if (dex_in == 0)
            return;
        else
            radixSort(suffixes, n, dex_in - 1);
    }

    int *AmanSufArrayay(string text, int n)
    {
        struct suffix suffixes[n];

        for (int i = 0; i < n; ++i)
        {
            suffixes[i].dex_in = i;
            suffixes[i].s[0] = text[i] - 'a';
            suffixes[i].s[1] = ((i + 1) < n) ? (text[i + 1] - 'a') : -1;
        }
        radixSort(suffixes, n, 1);
        int ind[n];
        for (int k = 4; k < 2 * n; k *= 2)
        {
            int old_rank = suffixes[0].s[0];
            int rank = 0;
            suffixes[0].s[0] = 0;
            ind[suffixes[0].dex_in] = 0;
        
            for (int i = 1; i < n; ++i)
            {
                if (suffixes[i].s[0] == old_rank && suffixes[i].s[1] == suffixes[i - 1].s[1])
                {
                    old_rank = suffixes[i].s[0];
                    suffixes[i].s[0] = rank;
                }
                else
                {
                    old_rank = suffixes[i].s[0];
                    ++rank;
                    suffixes[i].s[0] = rank;
                }
                ind[suffixes[i].dex_in] = i;
            }
            for (int i = 0; i < n; ++i)
            {
                int nextdex_in = suffixes[i].dex_in + k / 2;
                suffixes[i].s[1] = (nextdex_in < n) ? suffixes[ind[nextdex_in]].s[0] : -1;
            }
            radixSort(suffixes, n, 1);
        }
        int *SufArray = new int[n];
        for (int i = 0; i < n; i++)
            SufArray[i] = suffixes[i].dex_in;
        return SufArray;
    }

    int *Calculate_LCP(std::string txt, int *SufArray, int n)
{
    int *lcp = new int[n];
    int *invSufArray = new int[n];
    for (int i = 0; i < n; ++i)
        invSufArray[SufArray[i]] = i;

    int k = 0;

    for (int i = 0; i < n; ++i)
    {
        if (invSufArray[i] == n - 1)
        {
            k = 0;
            continue;
        }
        int j = SufArray[invSufArray[i] + 1];
        while ((j + k < n && i + k < n) && txt[i + k] == txt[j + k])
            ++k;

        lcp[invSufArray[i]] = k;
        if (k > 0)
            --k;
    }
    return lcp;
}
};




void solve()
{


    string s;
    cin >> s;
    int n,k;
    n = s.length();
    cin>>k;
    suffix suf;
    int *SufArray = suf.AmanSufArrayay(s, n);
    string ans="";
	
    for(int i=0;i<1+n-k;i++)
    {
		string st="";
		int j=SufArray[i];
		int l=SufArray[i+k-1];
		while(s[j]==s[l] && j<n && l<n)
        {
			st=st + s[j];
			l=l+1;
            j=j+1;
		}
		if(ans.size()<st.size())
            ans=st;
	}
	
	if(ans!="")
	    std::cout<<ans.length()<<std::endl;
	else std::cout<<-1<<std::endl;





}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
