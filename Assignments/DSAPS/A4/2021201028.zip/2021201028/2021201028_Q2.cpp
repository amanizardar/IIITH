
//Author :-> Aman Izardar
#include <iomanip>
#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <algorithm>


#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;

/* constants */

const size_t memsize = 1024 * 1024 * 400;

const size_t chunksize = memsize / sizeof(ll);

const string Temp_file_pre{"Temp_file_"};

const string Temp_file_suf{".txt"};

string merged_file{"merged.txt"};

//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

struct Compare
{

    bool operator()(pair<ll, ll> &p1, pair<ll, ll> &p2)
    {
        return p1.first >= p2.first;
    }
};

struct PriorityQueue
{
private:
    vector<pair<ll, ll>> A;

    ll PARENT(ll i)
    {
        return (i - 1) / 2;
    }

    ll LEFT(ll i)
    {
        return (2 * i + 1);
    }

    ll RIGHT(ll i)
    {
        return (2 * i + 2);
    }

    void heapify_down(ll i)
    {

        ll left = LEFT(i);
        ll right = RIGHT(i);

        ll smallest = i;

        if (left < size() && A[left].first < A[i].first)
        {
            smallest = left;
        }

        if (right < size() && A[right].first < A[smallest].first)
        {
            smallest = right;
        }

        if (smallest != i)
        {
            swap(A[i], A[smallest]);
            heapify_down(smallest);
        }
    }

    void heapify_up(ll i)
    {

        if (i && A[PARENT(i)].first > A[i].first)
        {

            swap(A[i], A[PARENT(i)]);
            heapify_up(PARENT(i));
        }
    }

public:
    unsigned ll size()
    {
        return A.size();
    }

    bool empty()
    {
        return size() == 0;
    }

    void push(ll key, ll value)
    {

        A.push_back({key, value});
        ll index = size() - 1;
        heapify_up(index);
    }

    void pop()
    {
        try
        {

            if (size() == 0)
            {
                throw out_of_range("Vector<X>::at() : "
                                   "index is out of range(Heap underflow)");
            }

            A[0] = A.back();
            A.pop_back();

            heapify_down(0);
        }
        catch (const out_of_range &oor)
        {
            cout << endl
                 << oor.what();
        }
    }

    pair<ll, ll> top()
    {
        try
        {

            if (size() == 0)
            {
                throw out_of_range("Vector<X>::at() : "
                                   "index is out of range(Heap underflow)");
            }

            return A.at(0);
        }

        catch (const out_of_range &oor)
        {
            cout << endl
                 << oor.what();
        }
        return {0, 0};
    }
};

void Temp_file_write(ll *const values, const size_t size, const size_t chunk)
{

    string output_file = (Temp_file_pre + to_string(chunk) + Temp_file_suf);

    ofstream ofs(output_file.c_str());

    for (ll i = 0; i < size; i++)
        ofs << values[i] << ' ';

    ofs << '\n';

    ofs.close();
}

string Merge_temp_files(size_t chunks, const string &merge_file)
{

    ofstream ofs(merge_file.c_str());

    // priority_queue<pair<ll,ll>,vector<pair<ll,ll>>,greater<pair<ll,ll>>>minHeap;
    PriorityQueue minHeap;

    ifstream *ifs_tempfiles = new ifstream[chunks];

    for (size_t i = 1; i <= chunks; i++)
    {
        ll topval = 0;

        string sorted_temp_file = (Temp_file_pre + to_string(i) + Temp_file_suf);

        ifs_tempfiles[i - 1].open(sorted_temp_file.c_str());

        if (ifs_tempfiles[i - 1].is_open())
        {
            ifs_tempfiles[i - 1] >> topval;
            minHeap.push(topval, (i - 1));
            // minHeap.push({topval, (i - 1)});
        }
    }

    int flag=0;

    while (minHeap.size() > 0)
    {
        ll next_val = 0;

        pair<ll, ll> min_pair = minHeap.top(); // get min

        minHeap.pop();

        if(flag==0)
        {
            ofs << min_pair.first;
            flag=1;
        }
        else
        ofs <<","<< min_pair.first; // write value to file

        flush(ofs);

        if (ifs_tempfiles[min_pair.second] >> next_val)
        {

            //   ipair np(next_val, min_pair.second);

            minHeap.push(next_val, min_pair.second);
            // minHeap.push({next_val, min_pair.second});
        }
    }

    // close open files
    for (ll i = 1; i <= chunks; i++)
    {
        ifs_tempfiles[i - 1].close();
    }
     for (size_t i = 1; i <= chunks; i++)
    {

        string sorted_temp_file = (Temp_file_pre + to_string(i) + Temp_file_suf);
        remove(sorted_temp_file.c_str());
    }

    ofs << '\n';
    ofs.close();

    delete[] ifs_tempfiles; // free memory

    return merged_file; // string
}

int main(int argc, char const *argv[])
{

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    if (argc != 3)
    {
        cout << "Please Provide Valid arguments" << endl;
        exit(0);
    }

    merged_file = argv[2]; //Outputfile name

    fstream infile(argv[1], ios::in);
    if (!infile.is_open())
    {
        cout << "File not found!\n";
        return 1;
    }

    ll *inputValues = new ll[chunksize];

    ll val = 0; 
    ll chunk = 1; 
    bool done = false;
    ll count = 0; 




    //reading input file

    string line;

    while (getline(infile, line))
    {
        istringstream ss(line);
        string element_string;

        while ((getline(ss, element_string, ',')))
        {
            val = stoll(element_string);
            done = false;
            inputValues[count] = val;

            count++;
            if (count == chunksize)
            {

                sort(inputValues, inputValues + count);

                Temp_file_write(inputValues, count, chunk); 

                chunk++;

                count = 0;

                done = true;
            }
        }
        if (!done) // one more file
        {
            sort(inputValues, inputValues + count);

            Temp_file_write(inputValues, count, chunk); // output vals to
        }
        else
        {
            chunk--;
        }
    }
    infile.close();
    delete[] inputValues;

    if (chunk == 0)
        cout << "no data found\n";
    else
        cout << "Sorted output is in file: " << Merge_temp_files(chunk, merged_file) << "\n";

    return EXIT_SUCCESS;

    return 0;
}
