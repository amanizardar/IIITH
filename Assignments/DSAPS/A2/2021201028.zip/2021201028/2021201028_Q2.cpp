
//Author :-> Aman Izardar
#include<iostream>
#include<sstream>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
#define MAX_SIZE 999959
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :



template<class T1,class T2>
class mymap
{
public:
	class Node
	{
	public:

		T1 key;
		T2 value;
		Node *next;


		Node(T1 key1,T2 value1)
		{
			key=key1;
			value=value1;
			next=NULL;
		}

	};

Node *arr[MAX_SIZE];


mymap()
{
	for(int i=0;i<MAX_SIZE;i++)
		arr[i]=NULL;
}

void insert(T1 key1 , T2 value1)
{
	string skey;
	stringstream sss;
	sss<<key1;
	sss>>skey;

	int hasval=hashfuns(skey);

	Node *root = arr[hasval];

	if(!root)
	{
		Node *newnode = new Node(key1,value1);
		arr[hasval]=newnode;
		return;
	}

	while(root)
	{
		if(root->key==key1)
		{
			root->value=value1;
			return;
		}
		root=root->next;
	}
	Node *newnode = new Node(key1,value1);
	newnode->next=root->next;
	root=newnode;
	arr[hasval]=root;
	
}

void erase(T1 key1)
{

	string skey;
	stringstream ss;
	ss<<key1;
	ss>>skey;

	int hasval=hashfuns(skey);

	Node *root = arr[hasval];

	if(!root)
	{
		return;
	}
	if(root->key==key1)
	{
		root=NULL;
		arr[hasval]=NULL;
		return;

	}
	while(root->next)
	{
		if(root->next->key==key1)
		{
			Node *temp=root->next;
			root->next=root->next->next;
			free(temp);
		}
		root=root->next;
	}


}


bool find(T1 key1)
{

	string skey;
	stringstream ss;
	ss<<key1;
	ss>>skey;

	int hasval=hashfuns(skey);

	Node *root = arr[hasval];

	if(!root)
	{
		return false;
	}
	if(root->key==key1)
	{
		return true;

	}
	while(root)
	{
		if(root->key==key1)
		{
			return true;
		}
		root=root->next;
	}
	return false;



}

T2 operator[](T1 key1)
{
	string skey;
	stringstream ss;
	ss<<key1;
	ss>>skey;

	int hasval=hashfuns(skey);

	Node *root = arr[hasval];
	T2 temp;

	if(!root)
	{
		insert(key1,temp);
		return temp;
	}

	if(root->key==key1)
	{
		return root->value;

	}
	while(root)
	{
		if(root->key==key1)
		{
			return root->value;
		}
		root=root->next;
	}
	
	insert(key1,temp);
	return temp;
}



ll hashfuns(string s)
{
	ll p=53;
	ll powerp=1;
	ll hasval=0;


	for(ll i=0;i<s.length();i++)
	{
		hasval=(hasval+(s[i]-'a'+ 1)*powerp)%MAX_SIZE;

		powerp=(powerp*p)%MAX_SIZE;
	}
	return (hasval%MAX_SIZE+MAX_SIZE)%MAX_SIZE;
}

};

// template<class string,class t2 >
// class mymap
// {

// t2 arr[MAX_SIZE];




// };





void solve()
{


mymap<int,string>m;
m.insert(1,"hi");
m.insert(1,"guy");
m.insert(2,"shy");
// cout<<m[1];
// cout<<m.find(3)<<endl;
// cout<<m.find(1)<<endl;
// m.erase(1);
// cout<<m.find(1)<<endl;
// cout<<m[2]<<endl;
cout<<"hi";
// mymap<float,int>m;
// m.insert(1.2,3);
// cout<<m.find(1.2)<<endl;
// m.erase(3);
// cout<<m.find(1.2)<<endl;
// m.erase(1.2);
// cout<<m.find(1.2)<<endl;





//Solving Question Find count of distinct elements in every sub-array of size k


// mymap<int,int>m;

// int n,k;
// cin>>n>>k;
// int a[n];
// for (int i = 0; i < n; ++i)
// {
// 		cin>>a[i];
// }

// int dist=0;

// for(int i=0;i<k;i++)
// {
// 	if(!m.find(a[i]))
// 	{
// 		m.insert(a[i],1);
// 		dist++;
// 	}
// 	else
// 	{
// 		int val=m[a[i]];
// 		m.insert(a[i],++val);
// 	}
// }
// cout<<dist<<" ";
// for(int i=k;i<n;i++)
// {
// 	if(m[a[i-k]]>1)
// 	{
// 		int val=m[a[i-k]];
// 		m.insert(a[i-k],--val);
// 	}
// 	else
// 	{
// 		dist--;
// 		m.erase(a[i-k]);
// 	}

// 	if(m.find(a[i]))
// 	{
// 		int val=m[a[i]];
// 		m.insert(a[i],++val);
// 	}
// 	else
// 	{
// 		dist++;
// 		m.insert(a[i],1);
// 	}
// 	cout<<dist<<" ";
// }





}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}

