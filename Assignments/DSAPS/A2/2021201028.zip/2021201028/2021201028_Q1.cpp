//Author :-> Aman Izardar

#include<iostream>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

class Complex
{
	public:
	int real;
	int img;

	Complex()
	{
        real=0;
		img=0;
	}
	
	Complex(int real1 ,int img1)
	{
		real=real1;
		img=img1;
	}

	// bool operator<(Complex b)
	// {
	// 	if(real<b.real)
	// 		return true;
	// 	if(real==b.real and img<b.img)
	// 		return true;
	// 	return false;
	// }
	// bool operator>(Complex b)
	// {
	// 	if(real>b.real)
	// 		return true;
	// 	if(real==b.real and img>b.img)
	// 		return true;
	// 	return false;
	// }
	// bool operator>=(Complex b)
	// {
	// 	if(real>b.real )
	// 		return true;
	// 	if(real==b.real and img>=b.img)
	// 		return true;
	// 	return false;
	// }

	// bool operator<=(Complex b)
	// {
	// 	if(real<b.real )
	// 		return true;
	// 	if(real==b.real and img<=b.img)
	// 		return true;
	// 	return false;
	// }

	// bool operator==(Complex b)
	// {
		
	// 	if(real==b.real and img==b.img)
	// 		return true;
	// 	return false;
	// }


};


class comparator
{
public:
    int compare(Complex a, Complex b)
    {

        if (a.real < b.real || a.real == b.real && a.img < b.img)
        {
            return 1; //less than
        }
        else if (a.real> b.real || a.real == b.real && a.img > b.img)
        {
            return 2; //greater
        }
        else if (a.real == b.real && a.img == b.img)
        {
            return 3; //equal
        }
        return 0;
    }
};

template<class T>
class AvlTree
{

public:

	class Node
	{
	public:
		T value;
		int count;
		Node *left;
		Node *right;
		int height;
		int rc;
		int lc;

		Node()
		{

		}

		Node(T value1)
		{
		value=value1;
		count=1;
		left=NULL;
		right=NULL;
		height=1;
		rc=0;
		lc=0;
		}
	};
	Node *root;

	AvlTree()
	{
		root=NULL;
	}


	Node* leftrot(Node* root)
	{
		Node *y=root->right;
		Node *child=y->left;

		y->left=root;
		root->right=child;

		root->height=max(getheight(root->left),getheight(root->right))+1;
		y->height=max(getheight(y->left),getheight(y->right))+1;

		if(!child)
			root->rc=0;
		else
		root->rc=child->rc+1;

		y->lc=(root)?root->lc+1:0;
		y->lc+=(child)?child->lc+1:0;


		return y;

	}

	Node* rightrot(Node* root)
	{
		Node *y=root->left;
		Node *child=y->right;

		y->right=root;
		root->left=child;

		root->height=max(getheight(root->left),getheight(root->right))+1;
		y->height=max(getheight(y->left),getheight(y->right))+1;


		y->rc=(root)?root->rc+1:0;
		y->rc+=(child)?child->rc+1:0;


		if(!child)
			root->lc=0;
		else
		root->lc=child->lc+1;

		return y;

	}

	int getheight(Node *root)
	{
    if (root == NULL)
        return 0;
    return root->height;
	}

	int Bal(Node *root)
	{
    if (root == NULL)
        return 0;
    return getheight(root->left) - getheight(root->right);
	}

	Node* inordersucc(Node *root)
	{
		while(root->left)
		{
			root=root->left;
		}
		return root;
	}


	void insert(T value)
	{
		
		root = insertfun(root,value);
	}

	Node* insertfun(Node *root,T value)
	{
		if(!root)
		{
			Node* newnode = new Node(value);
			return newnode;
		}

		if(value<root->value)
		{
			root->left=insertfun(root->left,value);
			root->lc++;
			
			
		}
		else if(value>root->value){
			
			root->right=insertfun(root->right,value);
			root->rc++;

		}
		else
		{
			root->count++;
			return root;
		}

		root->height=1+max(getheight(root->left),getheight(root->right));

		int balance = Bal(root);

		if (balance > 1 && root->left and value < root->left->value)
		{
			// cout<<"hi1"<<endl;
        return rightrot(root);
    	}


		if (balance < -1 && root->right and value > root->right->value)
		{
			// cout<<"hi2"<<endl;
        return leftrot(root);
 		}
    	
    	if (balance > 1 && root->left and value > root->left->value)
    	{
    		// cout<<"hi3"<<endl;
    	    root->left = leftrot(root->left);
    	    return rightrot(root);
    	}
 	
    	
    	if (balance < -1 && root->right and value < root->right->value)
    	{
    		// cout<<"hi4"<<endl;
    	    root->right = rightrot(root->right);
    	    return leftrot(root);
    	}
 	
    
    	return root;
	}

	void insert(T value,comparator cmp)
	{
		
		root = insertfun(root,value,cmp);
	}


    Node* insertfun(Node *root,T value ,comparator cmp)
	{
		if(!root)
		{
			Node* newnode = new Node(value);
			return newnode;
		}

		if(cmp.compare(value,root->value)==1)
		{
            // cout<<"hello left";
			root->left=insertfun(root->left,value,cmp);
			root->lc++;
			
			
		}
		else if(cmp.compare(value,root->value)==2){
            // cout<<"hello right";
			
			root->right=insertfun(root->right,value,cmp);
			root->rc++;

		}
		else
		{
            // cout<<"hello equal";
			root->count++;
			return root;
		}

		root->height=1+max(getheight(root->left),getheight(root->right));

		int balance = Bal(root);

		if (balance > 1 && root->left and cmp.compare(value , root->left->value)==1)
		{
			// cout<<"hi1"<<endl;
        return rightrot(root);
    	}


		if (balance < -1 && root->right and cmp.compare(value , root->right->value)==2)
		{
			// cout<<"hi2"<<endl;
        return leftrot(root);
 		}
    	
    	if (balance > 1 && root->left and cmp.compare(value , root->left->value)==2)
    	{
    		// cout<<"hi3"<<endl;
    	    root->left = leftrot(root->left);
    	    return rightrot(root);
    	}
 	
    	
    	if (balance < -1 && root->right and cmp.compare(value , root->right->value)==1)
    	{
    		// cout<<"hi4"<<endl;
    	    root->right = rightrot(root->right);
    	    return leftrot(root);
    	}
 	
    
    	return root;
	}

	void Delete(T value)
	{
		if(search(value))
		root=deletefun(root,value);
	}


	Node* deletefun(Node* root, T value)
	{
		if(!root)
			return root;

		if(value<root->value)
		{
			root->left=deletefun(root->left,value);
			root->lc--;
		}

		else if(value>root->value)
		{
			root->right=deletefun(root->right,value);
			root->rc--;
		}

		else
		{

			// if(root->count>1)
			// {
			// 	root->count--;
			// 	return root;
			// }

			// else
			// {


			if(!root->left and !root->right)
			{
				return NULL;
			}

			else if(!root->left)
			{
				Node *temp=root->right;
				free(root);
				return temp;
			}
			else if(!root->right)
			{
				Node *temp=root->left;
				free(root);
				return temp;
			}

			else
			{
				Node *succ = inordersucc(root->right);
				root->value=succ->value;
				root->right=deletefun(root->right,succ->value);
			}

			// }

		}

		if(root==NULL)
			return root;

		root->height=1+max(getheight(root->left),getheight(root->right));

		int balance = Bal(root);

		if (balance > 1 && root->left and value < root->left->value)
        return rightrot(root);


		if (balance < -1 && root->right and value > root->right->value)
        return leftrot(root);
 
    	
    	if (balance > 1 && root->left and value > root->left->value)
    	{
    	    root->left = leftrot(root->left);
    	    return rightrot(root);
    	}
 	
    	
    	if (balance < -1 && root->right and value < root->right->value)
    	{
    	    root->right = rightrot(root->right);
    	    return leftrot(root);
    	}
 	
    
    	return root;



	}


	void Delete(T value,comparator cmp)
	{
		if(search(value,cmp))
		root=deletefun(root,value,cmp);
	}

    Node* deletefun(Node* root, T value,comparator cmp)
	{
		if(!root)
			return root;

		if(cmp.compare(value,root->value)==1)
		{
			root->left=deletefun(root->left,value,cmp);
			root->lc--;
		}

		else if(cmp.compare(value,root->value)==2)
		{
			root->right=deletefun(root->right,value,cmp);
			root->rc--;
		}

		else
		{

			// if(root->count>1)
			// {
			// 	root->count--;
			// 	return root;
			// }

			// else
			// {


			if(!root->left and !root->right)
			{
				return NULL;
			}

			else if(!root->left)
			{
				Node *temp=root->right;
				free(root);
				return temp;
			}
			else if(!root->right)
			{
				Node *temp=root->left;
				free(root);
				return temp;
			}

			else
			{
				Node *succ = inordersucc(root->right);
				root->value=succ->value;
				root->right=deletefun(root->right,succ->value,cmp);
			}

			// }

		}

		if(root==NULL)
			return root;

		root->height=1+max(getheight(root->left),getheight(root->right));

		int balance = Bal(root);

		if (balance > 1 && root->left and cmp.compare(value , root->left->value)==1)
        return rightrot(root);


		if (balance < -1 && root->right and cmp.compare(value , root->right->value)==2)
        return leftrot(root);
 
    	
    	if (balance > 1 && root->left and cmp.compare(value , root->left->value)==2)
    	{
    	    root->left = leftrot(root->left);
    	    return rightrot(root);
    	}
 	
    	
    	if (balance < -1 && root->right and cmp.compare(value , root->right->value)==1)
    	{
    	    root->right = rightrot(root->right);
    	    return leftrot(root);
    	}
 	
    
    	return root;



	}



	bool search(T value)
	{
		Node *temp = root;

		while(temp)
		{
			if(temp->value==value)
				return true;
			else if(value<temp->value)
				temp=temp->left;
			else
				temp=temp->right;
		}
		return false;
	}

    bool search(T value ,comparator cmp)
	{
		Node *temp = root;

		while(temp)
		{
			if(cmp.compare(temp->value,value)==3)
				return true;
			else if(cmp.compare(value,temp->value)==1)
				temp=temp->left;
			else
				temp=temp->right;
		}
		return false;
	}



	void print()
	{
		printfun(root);
	}

	void printfun(Node *root)
	{
		if(root)
		{
			cout<<root->value<<"   "<<root->count<<" "<<root->rc<<" "<<root->lc<<endl;
			printfun(root->left);
			printfun(root->right);
		}
	}

	void print(comparator cmp)
	{
		printfun(root,cmp);
	}

	void printfun(Node *root,comparator cmp)
	{
		if(root)
		{
			cout<<root->value.real<<" "<<root->value.img<<"   "<<root->count<<" "<<root->rc<<" "<<root->lc<<endl;
			printfun(root->left,cmp);
			printfun(root->right,cmp);
		}
	}

	int count(T value)
	{
		if(!root)
			return 0;
		Node *temp=root;
		while(temp)
		{
			if(temp->value==value)
				return temp->count;
			else if(value<temp->value)
				temp=temp->left;
			else
				temp=temp->right;
		}
		return 0;
	}


    int count(T value ,comparator cmp)
	{
		if(!root)
			return 0;
		Node *temp=root;
		while(temp)
		{
			if(cmp.compare(temp->value,value)==3)
				return temp->count;
			else if(cmp.compare(value,temp->value)==1)
				temp=temp->left;
			else
				temp=temp->right;
		}
		return 0;
	}



	T lowerbound(T value)
	{
		Node *temp =lowerboundfun(root,value);
		if(!temp){
			cout<<"Not Exist"<<endl;
			static T valll;
			return valll;
		}
		else
			return temp->value;
	}
    T lowerbound(T value ,comparator cmp)
	{
		Node *temp =lowerboundfun(root,value ,cmp);
		if(!temp){
			cout<<"Not Exist"<<endl;
		    Complex valll;
			return valll;
		}
		else
			return temp->value;
	}

	Node* lowerboundfun(Node *root, T value)
	{
		if(!root)
			return NULL;
		if(root->value<value)
			return lowerboundfun(root->right,value);
		if(root->value==value)
			return root;
		if(root->value>value)
		{
			Node* temp = lowerboundfun(root->left,value);
			if(!temp)
				return root;
			return temp;
		}
		return NULL;
	}

    Node* lowerboundfun(Node *root, T value ,comparator cmp)
	{
		if(!root)
			return NULL;
		if(cmp.compare(root->value,value)==1)
			return lowerboundfun(root->right,value ,cmp);
		if(cmp.compare(root->value,value)==3)
			return root;
		if(cmp.compare(root->value,value)==2)
		{
			Node* temp = lowerboundfun(root->left,value,cmp);
			if(!temp)
				return root;
			return temp;
		}
		return NULL;
	}


	T upperbound(T value)
	{
		Node *temp= upperboundfun(root,value);
		if(!temp){
			cout<<"Not Exist"<<endl;
			static T valll;
			return valll;
		}
		else
		{
			return temp->value;
		}

	}

	Node* upperboundfun(Node *root, T value)
	{
		if(!root)
			return NULL;
		if(root->value<=value)
			return upperboundfun(root->right,value);
		if(root->value>value)
		{
			Node* temp = upperboundfun(root->left,value);
			if(!temp)
				return root;
			return temp;
		}
		return NULL;
	}

    T upperbound(T value ,comparator cmp)
	{
		Node *temp= upperboundfun(root,value,cmp);
		if(!temp){
			cout<<"Not Exist"<<endl;
			Complex valll;
			return valll;
		}
		else
		{
			return temp->value;
		}

	}

	Node* upperboundfun(Node *root, T value, comparator cmp)
	{
		if(!root)
			return NULL;
		if(cmp.compare(root->value,value)==1 || cmp.compare(root->value,value)==3)
			return upperboundfun(root->right,value,cmp);
		if(cmp.compare(root->value,value)==2)
		{
			Node* temp = upperboundfun(root->left,value,cmp);
			if(!temp)
				return root;
			return temp;
		}
		return NULL;
	}


	T closest(T value)
	{
		Node *temp = closestfun(root,value);
		if(!temp){
			cout<<"Not Exist"<<endl;
			static T valll;
			return valll;
		}
		else
		{
			return temp->value;
		}

	}

	Node* closestfun(Node *root, T value)
	{
		if(!root)
		{	
			return NULL;
		}

		if(root->value==value)
			return root;

		else if(root->value<value)
		{
			T diff1 = abs(root->value - value);

			Node * temp = closestfun(root->right,value);

			if(!temp)
				return root;

			T diff2 = abs(temp->value - value);

			if(diff1 < diff2)
				return root;
			else
				return temp;

		}
		else if(root->value>value)
		{
			T diff1 = abs(root->value - value);

			Node * temp = closestfun(root->left,value);

			if(!temp)
				return root;

			T diff2 = abs(temp->value - value);

			if(diff1 < diff2)
				return root;
			else
				return temp;
		}

		return NULL;

	}

    T closest(T value,comparator cmp)
	{
		Node *temp = closestfun(root,value,cmp);
		if(!temp){
			cout<<"Not Exist"<<endl;
		    Complex valll;
			return valll;
		}
		else
		{
			return temp->value;
		}

	}



	Node* closestfun(Node *root, T value,comparator cmp)
	{
		if(!root)
		{	
			return NULL;
		}

		if(cmp.compare(root->value,value)==3)
			return root;

		else if(cmp.compare(root->value,value)==1)
		{
			int diff1 = abs(root->value.real - value.real);

			Node * temp = closestfun(root->right,value,cmp);

			if(!temp)
				return root;

			int diff2 = abs(temp->value.real - value.real);

			if(diff1 < diff2)
				return root;
			else
				return temp;

		}
		else if(cmp.compare(root->value,value)==2)
		{
			int diff1 = abs(root->value.real - value.real);

			Node * temp = closestfun(root->left,value,cmp);

			if(!temp)
				return root;

			int diff2 = abs(temp->value.real - value.real);

			if(diff1 < diff2)
				return root;
			else
				return temp;
		}

		return NULL;

	}

	// T kthlargest(int k)
	// {
	// 	int count=0;
	// 	Node* temp=NULL;  
	// 	kthlargestfun(root,k,count,temp);
	// 	if(!temp){
	// 		cout<<"Not Exist"<<endl;
	// 		static T valll;
	// 		return valll;
	// 	}
	// 	else
	// 	{
	// 		return temp->value;
	// 	}
		
	// }

	// void kthlargestfun(Node* root,int k,int &count,Node *&ans)
	// {
	// 	if(!root or count>k)
	// 		return;

	// 	kthlargestfun(root->right,k,count,ans);
	// 	count=count+root->count;

	// 	if(ans)
	// 	{
	// 		return;
	// 	}

	// 	if(count>=k)
	// 	{
	// 	ans=root;
	// 	// cout<<root->value<<endl;
	// 	return ;
	// 	}

	// 	kthlargestfun(root->left,k,count,ans);

		

	// }


	T kthlargest(int k)
	{
		int count=0;
		Node* temp=kthlargestfun(root,k);
		if(!temp){
			cout<<"Not Exist"<<endl;
			static T valll;
			return valll;
		}
		else
		{
			return temp->value;
		}
		
	}

	Node* kthlargestfun(Node* node ,int k){
      
      if (node->rc +1 <= k and k<=  node->rc +node->count ) { 
        
        return node; 
      } 
      if (node->rc >= k) 
      
        return kthlargestfun(node->right,k) ;
      else { 
      
        return kthlargestfun( node->left , k - node->rc - node->count); 
      } 
    
	}

	T kthlargest(int k,comparator cmp)
	{
		int count=0;
		Node* temp=kthlargestfun(root,k,cmp);
		if(!temp){
			cout<<"Not Exist"<<endl;
			static T valll;
			return valll;
		}
		else
		{
			return temp->value;
		}
		
	}

    T kthlargestfun(Node* node ,int k,comparator cmp){
      
      if (node->rc +1 <= k and k<=  node->rc +node->count ) { 
        
        return node->value; 
      } 
      if (node->rc >= k) 
      
        return kthlargestfun(node->right,k ,cmp) ;
      else { 
      
        return kthlargestfun( node->left , k - node->rc - node->count ,cmp); 
      } 
    
}

	int countrange(T a, T b)
	{
		int count=0;
		countrangefun(root,a,b,count);
		return count;
	}
    int countrange(T a, T b ,comparator cmp)
	{
		int count=0;
		countrangefun(root,a,b,count,cmp);
		return count;
	}
	
	void countrangefun(Node *root, T a, T b, int &count)
	{
		Node *temp1 = root;
		Node *temp2 = root;
		int val1=0,val2=0;
		while(temp1)
		{
			if(temp1->value==a){
				val1+=temp1->lc+1;
				break;
			}
			if(temp1->value>a)
				temp1=temp1->left;
			else
			{
				val1+=temp1->lc+1;
				temp1=temp1->right;

			}
		}

		while(temp2)
		{
			if(temp2->value==b){
				val2+=temp2->lc+1;
				break;
			}
			if(temp2->value>b)
				temp2=temp2->left;
			else
			{
				val2+=temp2->lc+1;
				temp2=temp2->right;

			}
		}

		// cout<<val1<<" "<<val2<<endl;

		if(val1==0)
			count=val2-val1;
		else
		count=val2-val1+1;

		
	}


	void countrangefun(Node *root, T a, T b, int &count ,comparator cmp)
	{
		Node *temp1 = root;
		Node *temp2 = root;
		int val1=0,val2=0;
		while(temp1)
		{
			if(cmp.compare(temp1->value,a)==3){
				val1+=temp1->lc+1;
				break;
			}
			if(cmp.compare(temp1->value,a)==2)
				temp1=temp1->left;
			else
			{
				val1+=temp1->lc+1;
				temp1=temp1->right;

			}
		}

		while(temp2)
		{
			if(cmp.compare(temp2->value,b)==3){
				val2+=temp2->lc+1;
				break;
			}
			if(cmp.compare(temp2->value,b)==2)
				temp2=temp2->left;
			else
			{
				val2+=temp2->lc+1;
				temp2=temp2->right;

			}
		}

		// cout<<val1<<" "<<val2<<endl;

		if(val1==0)
			count=val2-val1;
		else
		count=val2-val1+1;
        

		
	}




};



// class Complex
// {
// 	public:
// 	int real;
// 	int img;

// 	Complex()
// 	{

// 	}
// 	Complex(int real1 ,int img1)
// 	{
// 		real=real1;
// 		img=img1;
// 	}

// 	// bool operator<(Complex b)
// 	// {
// 	// 	if(real<b.real)
// 	// 		return true;
// 	// 	if(real==b.real and img<b.img)
// 	// 		return true;
// 	// 	return false;
// 	// }
// 	// bool operator>(Complex b)
// 	// {
// 	// 	if(real>b.real)
// 	// 		return true;
// 	// 	if(real==b.real and img>b.img)
// 	// 		return true;
// 	// 	return false;
// 	// }
// 	// bool operator>=(Complex b)
// 	// {
// 	// 	if(real>b.real )
// 	// 		return true;
// 	// 	if(real==b.real and img>=b.img)
// 	// 		return true;
// 	// 	return false;
// 	// }

// 	// bool operator<=(Complex b)
// 	// {
// 	// 	if(real<b.real )
// 	// 		return true;
// 	// 	if(real==b.real and img<=b.img)
// 	// 		return true;
// 	// 	return false;
// 	// }

// 	// bool operator==(Complex b)
// 	// {
		
// 	// 	if(real==b.real and img==b.img)
// 	// 		return true;
// 	// 	return false;
// 	// }


// };


void solve()
{

	// Functions Implemented : 1) insert(value)
	// 						   2) Delete(value)
	// 						   3) search(value)
	// 						   4) print()
	// 						   5) count(value)
	// 						   6) lowerbound(value)
	// 						   7) upperbound(value)
	// 						   8) closest(value)
	// 						   9) kthlargest(k)
	// 						  10) countrange(starting value,ending value)






// AvlTree<int>a;

// a.insert(10);
// a.insert(10);
// a.insert(20);
// a.insert(30);
// a.insert(40);
// a.insert(50);
// a.insert(25);
// a.insert(10);
// a.insert(10);
// a.Delete(25);
// a.Delete(10);
// a.Delete(50);
// cout<<a.search(10)<<endl;
// cout<<a.search(88)<<endl;


// a.insert(33);
// a.insert(33);
// a.insert(33);
// a.insert(33);
// a.insert(33);
// a.insert(33);
// a.Delete(33);
// a.insert(1);
// a.insert(2);
// a.insert(3);
// a.insert(4);
// a.insert(4);
// a.insert(5);
// a.insert(6);



// a.print();


// cout<<a.count(10)<<endl;

// cout<<a.lowerbound(52)<<endl;
// cout<<a.upperbound(50)<<endl;
// cout<<a.closest(15)<<endl;
// cout<<a.kthlargest(8)<<endl;



// cout<<a.countrange(20,40)<<endl;
// cout<<a.countrange(10,20)<<endl;
// cout<<a.countrange(10,50)<<endl;
// cout<<a.countrange(0,30);



//  

	// 
		// 
			// 
				// 
					// For Float





// AvlTree<int>myavl;
// myavl.insert(1);
// myavl.insert(1);
// myavl.insert(1);
// myavl.insert(1.1);
// myavl.insert(1.2);
// myavl.insert(1.1);
// myavl.insert(3.7);
// myavl.insert(6.9);
// myavl.Delete(6.9);


// myavl.print();

// cout<<myavl.search(4)<<endl;
// cout<<myavl.search(6.9)<<endl;
// cout<<myavl.search(1.1)<<endl;

// cout<<myavl.count(1.2)<<endl;
// cout<<myavl.count(1.1)<<endl;

// cout<<myavl.lowerbound(3.8)<<endl;
// cout<<myavl.upperbound(3.6)<<endl;
// cout<<myavl.kthlargest(2)<<endl;
// cout<<myavl.countrange(1,1.3);


//  

	// 
		// 
			// 
				// 
					// For Strings

// AvlTree<string>avl;
// avl.insert(1);
// avl.insert(2);
// avl.insert(3);
// cout<<avl.lowerbound(4);
// cout<<avl.count(2);
// avl.insert("buy");
// avl.insert("shy");
// avl.insert("shy");
// avl.insert("my");
// avl.insert("try");
// avl.insert("why");
// avl.insert("mumbaaaiii");

// avl.Delete("try");



// avl.print();

// cout<<avl.search("sigh")<<endl;
// cout<<avl.search("my")<<endl;

// cout<<avl.count("sigh")<<endl;
// cout<<avl.count("buy")<<endl;

// cout<<avl.lowerbound("guy")<<endl;
// cout<<avl.upperbound("guy")<<endl;

// cout<<avl.kthlargest(2)<<endl;

// cout<<avl.countrange("hi","my");





//  

	// 
		// 
			// 
				// 
					// For Complex No. Class




    AvlTree<Complex> a;
    comparator cmp;
    Complex c1(1,2);
    Complex c2(2,2);
    Complex c3(3,2);
    Complex c4(4,2);
     a.insertfun(a.root,c1,cmp);
     a.insertfun(a.root,c1,cmp);
     a.insertfun(a.root,c3,cmp);
     a.print(cmp);

    // cout<<a.count(c1,cmp);
    // a.root= a.deletefun(a.root,c1,cmp);
    // cout<<a.count(c1,cmp);
    // cout<<endl;
    // cout<<a.lowerbound(c4,cmp).real;
    // cout<<a.kthlargestfun(a.root,2,cmp).real;
    // cout<<a.closest(c2,cmp).real;

    // cout<<a.countrange(c1,c3,cmp);

}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}