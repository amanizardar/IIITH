
//Author :-> Aman Izardar
#include<iostream>
#define ll long long
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define phi 3.1415926536
#define mod 1000000007
using namespace std;




//Code Section : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : : :

#define MAX_SIZE 500000000

template<class T>
class mydeque
{
	T *arr=new T[MAX_SIZE];
	ll front;
	ll rear;
	ll size;

public:
	mydeque()
	{
		front=-1;
		rear=-1;
		size=0;
	}
	mydeque(ll n,T x)
	{
		front=-1;
		rear=-1;
		size=0;
		for(int i=0;i<n;i++)
			push_back(x);
	}

	void push_back(T val)
	{
		if((rear+1)%MAX_SIZE==front)
			cout<<"Overflow";
		else if(front==-1 and rear==-1)
		{
			front=0;
			rear=0;
			arr[rear]=val;
			size++;
		}
		else
		{
			rear=(rear+1)%MAX_SIZE;
			arr[rear]=val;
			size++;
		}
	}

	void push_front(T val)
	{
		if((front==0 && rear==MAX_SIZE-1) || (front==rear+1))
			cout<<"Overflow";
		else if(front==-1 and rear==-1)
		{
			front=0;
			rear=0;
			arr[front]=val;
			size++;
		}
		else
		{
			if(front==0)
				front=MAX_SIZE-1;
			else
				front=front-1;
			arr[front]=val;
			size++;
		}
	}
	T pop_back()
	{
		if(front==-1 and rear==-1)
			return -1;
		else if(front==rear)
		{
			T ele=arr[rear];
			front=-1;
			rear=-1;
			size--;
			return ele;
		}
		else
		{
			T ele=arr[rear];
			if(rear==0)
				rear=MAX_SIZE-1;
			else
				rear--;
			size--;
			return ele;

		}

	}

	T pop_front()
	{
		if(front==-1 and rear==-1)
			return -1;
		else if(front==rear)
		{
			T ele=arr[rear];
			front=-1;
			rear=-1;
			size--;
			return ele;
		}
		else
		{
			T ele=arr[front];
			if(front==MAX_SIZE-1)
				front=0;
			else
				front++;
			size--;
			return ele;

		}


	}

	T Back()
	{
		static T temp;
		if(front==-1 and rear==-1)
			return temp;
		return arr[rear];
	}
	T Front()
	{	
		static T temp;
		if(front==-1 and rear==-1)
			return temp;
		return arr[front];
	}

	T find(T val)
	{
		if(front==-1 and rear==-1)
			return -1;
		int i=front;

		while(i!=rear)
		{
			if(arr[i]==val)
				return i;
			
		}
		return -1;
	}

	bool empty()
	{
		if(rear==-1 and front==-1)
			return true;
		return false;
	}

	ll Size()
	{
		return size;
	}

	void clear()
	{
		size=0;
		front=-1;
		rear=-1;
	}

	T operator[](ll i)
	{
		return arr[(front+i)%MAX_SIZE];
	}

	void resize(ll x, T d)
	{
		if(x==size)
		{
			return;
		}
		else if(x>size)
		{
			for(ll i=size;i<x;i++)
			{
				push_back(d);
			}
		}
		else
		{
			for(ll i=size;i>x;i--)
				pop_back();
		}

	}

};


void solve()
{

// mydeque<int>q;
// q.push_back(2);
// q.push_back(3);
// q.push_back(4);
// q.push_back(5);
// q.pop_back();
// q.push_front(6);
// q.push_front(7);
// q.push_front(8);
// q.pop_front();

// cout<<q.begin();

mydeque<long double>q1(10,0);
// cout<<q1.begin();
q1.push_front(8);
q1.push_front(9);
// cout<<q1.Size()<<endl;
// cout<<q1.Front()<<endl;
// cout<<q1[0];
q1.resize(15,3);
// cout<<q1.Size()<<endl;
// cout<<q1.Back();
q1.resize(5,0);
cout<<q1.Size()<<endl;












}









int main()
{

 ios_base::sync_with_stdio(false);
 cin.tie(NULL);
 #ifndef ONLINE_JUDGE
 freopen("input.txt", "r", stdin);
 freopen("output.txt", "w", stdout);
 #endif
ll t=1;
//cin>>t;
while(t--)
{
    solve();
}
return 0;
}
