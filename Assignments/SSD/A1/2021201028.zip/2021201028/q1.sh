#!/bin/bash
#Aman Izardar
#This Script is For Question 1.

# a) When the script is executed from the current directory, it should print all the directories ONLY present in its current directory
# Script command ::::::::::::::



#du -sh */ |tr "/" " "| awk '{t1=$1;t2=$2; print t2,t1}'|column -t

#echo "PART B"

# b) The output should sort the directory listing by size in decreasing order
#Script Command :::::::::::::

total=`ls -l | grep "^d" | wc -l`
if [[ $total -eq 0 ]]
then 
exit
fi

du -sh */ |sort -hr|tr "/" " "| awk 'BEGIN{OFS="\t"}{t1=$1;t2=$2; print t2,t1}'


