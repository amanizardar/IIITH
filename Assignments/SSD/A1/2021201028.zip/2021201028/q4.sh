#!/bin/bash
#Author Aman Izardar
#
#Question 4
#
#



#Following Function Deci Converts Roman no. to Decimal no.

deci()
{
roman_numerals=$(echo $1 | tr a-z A-Z)

# Test that it is valid
[[ "${roman_numerals//[IVXLCDM]/}" == "" ]] || \
    { echo Roman numerals ${roman_numerals} contains invalid characters ; 
    exit 1 ;}

number=$(echo ${roman_numerals} | sed 's/CM/DCD/g' | sed 's/M/DD/g' | sed 's/CD/CCCC/g' | sed 's/D/CCCCC/g' | sed 's/XC/LXL/g' |
    sed 's/C/LL/g' | sed 's/XL/XXXX/g' | sed 's/L/XXXXX/g' | sed 's/IX/VIV/g' | sed 's/X/VV/g' | sed 's/IV/IIII/g' | sed 's/V/IIIII/g' |
    tr -d '\n' | wc -m)
}


#Following function is a subfunction of the function roman()

SubValue()
{
  romanvalue="${romanvalue}$2"
  decvalue=$(( $decvalue - $1 ))
}


#The is roman() function. It converts Decimal no. to Roman no.

roman()
{
decvalue=$1
while [ $decvalue -gt 0 ] ; do
if [ $decvalue -ge 1000 ] ; then
  SubValue 1000 "M"
elif [ $decvalue -ge 900 ] ; then
  SubValue 900 "CM"
elif [ $decvalue -ge 500 ] ; then
  SubValue 500 "D"
elif [ $decvalue -ge 400 ] ; then
  SubValue 400 "CD"
elif [ $decvalue -ge 100 ] ; then
  SubValue 100 "C"
elif [ $decvalue -ge 90 ] ; then
  SubValue 90 "XC"
elif [ $decvalue -ge 50 ] ; then
  SubValue 50 "L"
elif [ $decvalue -ge 40 ] ; then
  SubValue 40 "XL"
elif [ $decvalue -ge 10 ] ; then
  SubValue 10 "X"
elif [ $decvalue -ge 9 ] ; then
  SubValue 9 "IX"
elif [ $decvalue -ge 5 ] ; then
  SubValue 5 "V"
elif [ $decvalue -ge 4 ] ; then
  SubValue 4 "IV"
elif [ $decvalue -ge 1 ] ; then
  SubValue 1 "I"
fi
done
}




#Counting total no. of arguments passed
totalarg="$#"

#If only one argument passed then according to the question it is an integer and we need to convert it to roman no.
# i.e
# a). If you pass one INTEGER as an argument to the BASH script, then return its equivalent ROMAN Number as output
if [[ $totalarg -eq 1 ]];then
roman $1
echo $romanvalue

# b). If you pass two INTEGERS as two arguments the BASH script, return the SUM of two integers in the form of ROMAN numbers
elif [[ $totalarg -eq 2 ]];then
if [ "$1" -eq "$1" ] 2>/dev/null; then   # checking if the no. passed is integer or not.If Yes we sum the integers and return roman no. of the sum.
	value=$(($1 + $2))
	roman $value
	echo $romanvalue
else

# c). If you pass two ROMAN numbers as two arguments the BASH script, return the SUM of two ROMAN numbers in the form of INTEGERS
     deci $1          # converting first roman to decimal
     first=$number
     deci $2	       # Converting second roman to decimal
     second=$number
     echo $(($first + $second))  # returning sum of the two given no.
fi
fi




