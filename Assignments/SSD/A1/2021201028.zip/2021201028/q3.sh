#!/bin/bash
#Author Aman Izardar
#
#Question 3
#
#




# a). Take a word (string) as an input as an argument
word=$1

# b). Check whether the input work contains any BASH command by permuting the letters of the input word
newword=`echo $word | grep -o . | sort | tr -d "\n"`
len=${#word}
# cmd.txt is a file which after executing the following commands will store all the bash commands.
touch cmd.txt
#compgen -c>>cmd.txt
compgen -c |awk "length == $len"> cmd.txt
sort -uo cmd.txt cmd.txt

#common.txt is a file which will contain the strings which are present in both output.txt and cmd.txt , means common.txt will contain all the valid bash commands possible with the permutation of the given string.
rm common.txt
touch common.txt


file=cmd.txt
while read line; do
for word in $line;do
curr=`echo $word | grep -o . | sort | tr -d "\n"`
[[ $curr == $newword ]] && echo "$word">>common.txt 
done
done<$file
echo ""

# lc is a variable which will store no. of lines in common.txt i.e. valid bash commands no.

lc=$(wc -l common.txt| awk '{ print $1 }')

#if there is no lines in common.txt means lc==0 then it means no permutation of the given string is a valid bash command.
#d) print NO followed by the input string
if ((lc==0));then 
echo "NO $1"
else       #c).If a BASH Command exists, print YES, followed by the BASH command
printf "Yes " 
file=common.txt
while read line; do
for word in $line;do
printf "$word \t"  #e).If there is more than one command, print them with a tab delimiter.
done
done<$file
fi
echo ""
rm cmd.txt common.txt
