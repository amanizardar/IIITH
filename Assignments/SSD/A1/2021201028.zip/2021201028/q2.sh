#!/bin/bash
#Author Aman Izardar
#
#Question 2 Script.
#
# a)Please Pass input.txt and output.txt files as arguments to the shell script

# b) The input.txt contains some random text

# c) Print all the words ending with ing in new line inside output.txt file


file=$1
#printf "################This is the output file for question 2#############\n">$2
printf "">$2
while read line; do
for word in $line;do
if [[ "${word,,}"  == *ing ]]
then
printf "${word,,}\n" >>$2
fi
done
done < $1
