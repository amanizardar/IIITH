
#!/bin/bash
#Author Aman izardar
#
#
#Question 5
#
#



# if temp_activity already exist then delete it.
rm -r temp_activity

# creating a directory temp_activity
mkdir temp_activity

#b). Inside this directory, create files temp<i>.txt, substitute <i> with numbers from 1 to 50.Thus, you’ll have 50 files with names temp1.txt, temp2.txt, … Achieve this with a single command without loop.
touch temp_activity/temp{1..50}.txt

#c). Change the extensions of files from temp1 to temp25 from txt to md
for file in temp_activity/temp{1..25}.txt
do
  mv "$file" "${file%.txt}.md"
done

#d).For all the files, change the name from

  #a).temp<i>.<extension> to temp<i>_modified.<extension> where <i> is between 1 to 50

for file in temp_activity/temp{1..25}.md
do
  mv "$file" "${file%.md}_modified.md"
done

for file in temp_activity/temp{26..50}.txt 
do
  mv "$file" "${file%.txt}_modified.txt"
done

  #b).Among these files with extension belonging to txt and md, ZIP all the .txt files ONLY and name the ZIP file as txt_compressed.zip
zip -j temp_activity/txt_compressed.zip temp_activity/*.txt















