***
//////////////////////////// This is a Readme file for SSD assignment //////////////////////////////
Name    :-> Aman Izardar
Email   :-> aman.izardar@students.iiit.ac.in
Roll No :-> 2021201028 
***
                                    Que 1
First we need to check if current folder contains any subdir. or not.
For that i have used ls -l command and filter out the rows based on the directory.
and count the total no. of lines.
- If total lines= 0 that means we don't have any folder (dir) in current dir. 
So we'll exit from the script without printing anything.
- If Current Dir contains some subdir then using du cmd we'll print all the those dir sizes.

**No Special Keyword, Permissions, or requirements needed to run this script.**
***
                                    Que 2   
- This Script takes two text files as args. First one to look for the words and second one for the output.
- Input file name will be saved in a variable called "file".
- Using for and while loop i'll check each word if that is ending with "ing" then simply append it to output file i.e. in arg no. 2.

***
                                    Que 3
**Note:- This Script Generate Two Temp files called common.txt and cmd.txt and they will be deleted automatically**
- This Script takes one word as an arg.
- sort the given word and store it in a new variable.
- Generate all the cmds of length equals to the length of the given word and then after sorting store all the cmds in a text file called cmd.txt
- now compared each cmd with our new sorted word if matched then output this cmd to a new file called common.txt
- If size of Common.txt is 0 then output NO.
- else output each word seprated by tab.

***
                                    Que 4 
- First count total number of arg passed.
- If it is 1 then it means we need to convert given int to roman value, so for that pass the given int to fun roman. "roamn" fun takes the given int and convert it to Roman value and after that we'll print that value.
- If two int passed to the scipt then we'll sum both int and again pass the sum to the roman fun.
- If two roman values are passed to the script then we'll convert each roman to decimal value by calling deci fun, after that sum the value and print it.
***
                                    Que 5
- First check if temp_activity aleady exist, if yes delete it using rm cmd.
- after that make temp_activity folder and using touch cmd create the files in a range of 1..50 
- Using for loop and mv cmd changed first 25 file's extension from txt to md.
- Using for loop and mv cmd modified the file's name.
- using zip cmd compressed all the test files in a txt_compressed.zip

**No Special Keyword, Permissions, or requirements needed to run this script.**
***

