# amanizardar.github.io
portfolio-Personal Homepage

It is a single page website.
containing multiple tabs
Included profile image and some other images also.
linked external website as hyperlink :- codechef hackerank etc.
Inluded table in Time and Date part.
It is a  mobile friendly website.
CV included as external link.
Filled with content like skills , Education, contact etc.
professional social media contacts linked.
Used different fonts and designs.
Current date and time included.
