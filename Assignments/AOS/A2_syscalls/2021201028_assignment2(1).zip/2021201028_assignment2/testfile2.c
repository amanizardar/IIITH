#define _GNU_SOURCE
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/syscall.h>
#include <string.h>
#include "myheader.h"

int main(void){
	
    char st[256];
   sprintf(st,"Aman");
   
    
    int Check = amanprint(st);
    if(Check==0)
        printf("amanprint SystemCall Successfully called\n");
    else
        printf("Error Please Try Again");

  
   
     return 0;
}
