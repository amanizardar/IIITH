#include <linux/unistd.h> 

#define __NR_amanhello   548
#define __NR_amanprint   549
#define __NR_amanprocess 550
#define __NR_amangetpid  551


int  amanhello() 
{ 
        return syscall(__NR_amanhello); 
} 


int  amanprint(char *st) 
{ 

	const int a=150;
	return syscall( __NR_amanprint,st,a);
        
} 


int amanprocess()
{
	return syscall(__NR_amanprocess);
}

int amangetpid()
{
	return syscall(__NR_amangetpid);
}
