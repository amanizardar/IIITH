#include <linux/kernel.h>
//#include<linux/current.h>
#include <linux/sched.h>


asmlinkage long amanprocess(void)
{
	
        printk("My current process id/pid is %d\n", current->pid);
       // printk("My current parent process id/ppid is %d\n", current->ppid);
       
       struct task_struct __rcu *real_parent;
        printk("My Parent Process id/ppid is %d\n", task_pid_nr(rcu_dereference(current->real_parent)));
        return 0;
}
