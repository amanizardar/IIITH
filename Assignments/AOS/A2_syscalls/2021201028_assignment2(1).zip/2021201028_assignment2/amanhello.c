#include <linux/kernel.h>

asmlinkage long sys_amanhello(void)
{
        printk("Hello this is a msg from amanhello syscall \n");
        return 0;
}
