#include <linux/kernel.h>
#include <linux/sched.h>
#define _GNU_SOURCE
 //#include <unistd.h>
 //int getpid(void){
 //return  syscall(39);
 //}
 
asmlinkage long amangetpid(void)
{
	//int mypid= getpid();
        printk("Hello this is the msg from amangetpid syscall");
        printk("process id is :%d",current->pid);
        
      
        return current->pid;
}
