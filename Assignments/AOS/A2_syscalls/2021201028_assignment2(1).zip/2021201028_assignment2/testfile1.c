#include <stdio.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>
#include "myheader.h"

int main()
{
       int Check = amanhello();
       
       if(Check==0)
        printf("amanhello SystemCall Successfully called\n");
        else
        printf("Error Please Try Again");
        return 0;
}

