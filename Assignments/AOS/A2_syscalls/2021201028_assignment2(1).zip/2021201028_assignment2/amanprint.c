#include <linux/kernel.h>
#include <linux/linkage.h>
#include <linux/syscalls.h>
#include <linux/uaccess.h>

SYSCALL_DEFINE2(amanprint,char __user *, src,int, len)
{
        char temp[256];
        unsigned long newlen = len;
        unsigned long currlen = sizeof(buf);
                while( newlen > 0 ){
                if( newlen < currlen ) currlen = newlen;
                if( copy_from_user(temp, src, currlen) ){
    		return -EFAULT;
    	}
                newlen -= currlen;
        }
    
        printk("Hello %s\n", buf);
    
        return 0;
}
