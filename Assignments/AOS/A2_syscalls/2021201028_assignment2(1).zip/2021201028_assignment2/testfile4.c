#include <stdio.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>
#include "myheader.h"

int main()
{	
	
        long int pid = amangetpid();
        printf("You process id is:- %ld\n", pid);
        return 0;
}

